//
//  ah8sXlRjtTf7Snp_User_hfSa.h
//  BlueDanube
//
//  Created by XQz5El9t6bfuYNvL on 2018/3/8.
//  Copyright © 2018年 XRtJvdQCu2_7ow . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "NzdM1Xxwm_OpenMacros_xdzN.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSArray *qvLxrlufOECY;
@property(nonatomic, strong) NSMutableDictionary *bgUxmukhYwDcKqAtij;
@property(nonatomic, strong) NSDictionary *ieBaNwzFkGObrs;
@property(nonatomic, strong) NSMutableArray *glIJpZirOumyGagURfdV;
@property(nonatomic, strong) NSArray *bmrWqCKTfUjYeHJAPlXIMsVhEyZ;
@property(nonatomic, strong) NSObject *tvfYPimLGasDoUFxN;
@property(nonatomic, strong) NSDictionary *evSUiIMhpnqlA;
@property(nonatomic, strong) NSNumber *ekDrCniRYdLeIHxAB;
@property(nonatomic, copy) NSString *spQTfnGiopBtFWZXzaqCdsDuJk;
@property(nonatomic, copy) NSString *fkLHJEUamVYvAKjBdTyD;
@property(nonatomic, copy) NSString *sfBmTowkJAurixangZHFCOKvs;
@property(nonatomic, strong) NSNumber *fwDsthVQlTeC;
@property(nonatomic, strong) NSObject *xmnIYvuLCXkD;
@property(nonatomic, strong) NSMutableArray *unwVjaXSOWRqKl;
@property(nonatomic, strong) NSArray *kwjvApHwdSFtxoLyENesQhJZcR;
@property(nonatomic, strong) NSMutableDictionary *rsobDHAdMCfmOJN;
@property(nonatomic, strong) NSDictionary *siekrNQEubvZALyj;
@property(nonatomic, strong) NSNumber *rtZFJzYWuasEIGvfVjKLxMXbCc;
@property(nonatomic, copy) NSString *kxXBbaoGYzPIxqTw;
@property(nonatomic, copy) NSString *xwAKVzNpRrPGHDhUoWmwI;
@property(nonatomic, strong) NSObject *hzuizRtGjsoLrxH;
@property(nonatomic, strong) NSDictionary *cjQkISHYnVJwOmZgyldzfWi;
@property(nonatomic, strong) NSArray *xmoQGNhRVMJgctFPeALvaBj;
@property(nonatomic, strong) NSNumber *kfmDbEYoVdhJIAuGTCgyZeLf;
@property(nonatomic, strong) NSDictionary *qeXUwnQSsNFBhpPjrb;
@property(nonatomic, strong) NSDictionary *omtwcsZLGgEyRbWDSCxVkpnUdzN;
@property(nonatomic, strong) NSDictionary *rzQCSlKApLzXFycvkbNg;
@property(nonatomic, strong) NSArray *dicVjEvqnMhLg;
@property(nonatomic, strong) NSNumber *gyCpoaQtYSAfm;
@property(nonatomic, strong) NSDictionary *elTGtOaCIpWy;
@property(nonatomic, strong) NSDictionary *apOTwsBPtxQH;
@property(nonatomic, strong) NSMutableArray *yiGcMSDbVzXyLOfraKPxWmodw;
@property(nonatomic, strong) NSMutableArray *lbCWfITwOhriU;
@property(nonatomic, copy) NSString *rcUsdXfpVizgkBJKQlIEStRxrFM;


/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
