//
//  g8AJgmkORHVy_Result_mA8kRyJ.h
//  BlueDanube
//
//  Created by X8FLMAWtxcTOVp on 2018/3/5.
//  Copyright © 2018年 qo_haSiZrA . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "b1POXEyrQvTq_OpenMacros_rvXEQq.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSArray *ovimPYKSgcoIQzdnO;
@property(nonatomic, strong) NSNumber *wcaMPBOphtokINjSGvUFd;
@property(nonatomic, strong) NSMutableArray *dnzXhtqvkFOiIuSlyZNfsd;
@property(nonatomic, copy) NSString *frJeqPIYHKnWZvmuRcAkiEfdLbQ;
@property(nonatomic, strong) NSMutableDictionary *osXWfInsQbqVdBAheuDLytx;
@property(nonatomic, copy) NSString *dwnKZQNkMGaRUW;
@property(nonatomic, strong) NSArray *bzKxcqGpbeWSytHRrodYuPA;
@property(nonatomic, strong) NSMutableDictionary *mjhOzkdQryPZYbSAtlK;
@property(nonatomic, strong) NSMutableArray *svKVEubgSAyWYOJnLDTkmMaCs;
@property(nonatomic, copy) NSString *sfqTUCdlxcFynJGNzBSKjQAw;
@property(nonatomic, strong) NSMutableArray *olKqpyTYuXiwFG;
@property(nonatomic, strong) NSNumber *jyJVNrtSCixTAc;
@property(nonatomic, strong) NSNumber *jsqFHlvCnsUQecTSwE;
@property(nonatomic, strong) NSObject *ctFMGvepZHxIlAbJo;
@property(nonatomic, strong) NSDictionary *sfYJCWbsghjUILrwnQFGl;
@property(nonatomic, strong) NSNumber *gzomHTWFDdwzkSctgrAP;
@property(nonatomic, strong) NSMutableArray *vkvPhfbMHecxsiWJVEKqXwr;
@property(nonatomic, strong) NSNumber *fqIGamXLtHCxqrKZviBh;
@property(nonatomic, strong) NSArray *qpDmEnFxMPqWjKAd;
@property(nonatomic, strong) NSNumber *shvpgJACoaONwdeKycuY;
@property(nonatomic, strong) NSMutableDictionary *shzQgiWCSmqbAko;
@property(nonatomic, strong) NSArray *daxcEDwkgtobhYJynpe;
@property(nonatomic, strong) NSObject *jsiltKSPdaXZIVJQuqfvmyj;
@property(nonatomic, strong) NSDictionary *fhIuUcjnbPxeMzNRLfBCdiFv;
@property(nonatomic, strong) NSObject *oybjCiLKdkry;
@property(nonatomic, strong) NSArray *ydtKVgcbLqTdRDwXamOe;
@property(nonatomic, strong) NSDictionary *itqPGawIDFedo;
@property(nonatomic, strong) NSMutableArray *pzSehKDGUJHXlRPbxkTpOsn;
@property(nonatomic, strong) NSMutableDictionary *qismahMNzZKqQOxipHYESjuk;
@property(nonatomic, strong) NSMutableDictionary *rbJZNhKQvgbWFsVkULBqCMHyYi;
@property(nonatomic, strong) NSNumber *gsxQWpwUYyObFAGZJvlojgz;
@property(nonatomic, strong) NSMutableDictionary *mopdQRkPuCImZWTtv;
@property(nonatomic, strong) NSObject *tqmkQSAMDHeUIuNvFiz;
@property(nonatomic, strong) NSDictionary *ryhVaIrJlkAXyYgWQSDqN;
@property(nonatomic, strong) NSObject *xmLCRSZmYDPkGaNAjBqefshV;
@property(nonatomic, strong) NSNumber *xlksIzTwrpeKUyWOM;
@property(nonatomic, copy) NSString *kbhRMuTpoiCdbZBglce;
@property(nonatomic, strong) NSMutableArray *worazfxRXgetDTLUWjOu;
@property(nonatomic, strong) NSObject *gheABOvlNgKModULQ;
@property(nonatomic, strong) NSNumber *teaNBTxoSWZLdlPcJOmCvEpsI;
@property(nonatomic, strong) NSMutableArray *jkfXmNndQWCDPSsyLEp;


/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
