//
//  TTMVgrR2Hil3Nzn_User_HNlVT.h
//  BlueDanube
//
//  Created by X8FLMAWtxcTOVp on 2018/3/8.
//  Copyright © 2018年 qo_haSiZrA . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "b1POXEyrQvTq_OpenMacros_rvXEQq.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSNumber *eqxEvFfJVnreAuBMtHgkjRsI;
@property(nonatomic, strong) NSNumber *xpRiyBrEzJFaMdfpLgPUKY;
@property(nonatomic, strong) NSMutableDictionary *xlUEABeNryQLHRJxMWZ;
@property(nonatomic, strong) NSMutableDictionary *yhRDWaIMoEdUOvrjQ;
@property(nonatomic, strong) NSNumber *yccIBOPnQlepxMgjHfVbEdrasCZ;
@property(nonatomic, strong) NSMutableDictionary *mqowIEvceMLqkxdjpt;
@property(nonatomic, strong) NSArray *kcImtdvFrYBeGgysUXNMkR;
@property(nonatomic, strong) NSMutableDictionary *hrsejlfQFdpHUiSJVWtGYx;
@property(nonatomic, strong) NSNumber *lsGdJKMgNteIxUAmjb;
@property(nonatomic, strong) NSMutableArray *jmRuYtCQjwmN;
@property(nonatomic, copy) NSString *vqwsPdOYtnmUQ;
@property(nonatomic, strong) NSMutableDictionary *tcSUwQmjtIeWsFl;
@property(nonatomic, strong) NSArray *ecAamWSwgRiGnQjyNoxrf;
@property(nonatomic, strong) NSDictionary *wuuxZTeKEfohFWbQpRtk;
@property(nonatomic, strong) NSMutableDictionary *joicjbdNxgkwzQa;
@property(nonatomic, strong) NSMutableDictionary *qvdlhBFsvkmefUouK;
@property(nonatomic, strong) NSNumber *ygaLsxzmiFcGr;
@property(nonatomic, strong) NSDictionary *ijsdPZUhjXroFfpRkvOTIHiq;
@property(nonatomic, strong) NSObject *exCKrJjNZvxdstg;
@property(nonatomic, strong) NSNumber *ecvoFciIxYwBZg;
@property(nonatomic, strong) NSMutableArray *ubFmTBuQEehwOnqSjX;
@property(nonatomic, strong) NSObject *obHpUoTxPFjORWh;
@property(nonatomic, strong) NSMutableDictionary *wtRxfbYrZMCBXwmQKOIgaPzqT;
@property(nonatomic, strong) NSNumber *srCcOuTPQfMIEmvqW;
@property(nonatomic, strong) NSArray *mrkdvZoBTgRNYnQzuL;
@property(nonatomic, strong) NSObject *bhAnclMZEmUtBJhKOTXV;
@property(nonatomic, strong) NSArray *tkMdthcXZiFQmAygpVHuGrJ;
@property(nonatomic, strong) NSMutableDictionary *seyWLPtpJwkYUjcBiSzHhT;
@property(nonatomic, strong) NSObject *owUjXtzGBhCRpuWJceDrFASVwnb;
@property(nonatomic, strong) NSObject *qdSmaByGlenXubVkYsRHLJz;
@property(nonatomic, strong) NSMutableDictionary *wdkTeilUHoaPrGBSXVCOLNf;
@property(nonatomic, copy) NSString *hdXHaYGZUPynh;
@property(nonatomic, strong) NSDictionary *naFMjuZHxVUBm;
@property(nonatomic, copy) NSString *wgHhFxsWUZuqJdK;
@property(nonatomic, strong) NSMutableArray *rgoxNUwrWXQD;
@property(nonatomic, strong) NSObject *suyRrlxnCJkqtL;
@property(nonatomic, strong) NSDictionary *tuTpJzUrYDRPWNMcAHev;
@property(nonatomic, strong) NSObject *acpYAxMcwNDuRsGeP;
@property(nonatomic, strong) NSNumber *zvzEnIlwGoPAVRkgLOMyqQWmr;
@property(nonatomic, strong) NSArray *qnpBSiJtNcrHGAVDYMgTCKU;
@property(nonatomic, strong) NSMutableArray *tkoDAjdBJvipZlgt;
@property(nonatomic, strong) NSDictionary *qyxXjZBTDEAikWyFJgIGp;
@property(nonatomic, strong) NSObject *ntZdEzxqNLoh;
@property(nonatomic, strong) NSObject *maAGCBJpPacYmutREsHjkv;
@property(nonatomic, strong) NSArray *zjOqHrszhpTEXASfvelGgY;
@property(nonatomic, strong) NSMutableArray *aryOuhAcmxVKQUzrYgkbfGtv;
@property(nonatomic, strong) NSMutableArray *gpfUeoTYKuSbOJdlatFZz;
@property(nonatomic, strong) NSMutableDictionary *heIGpAHRqeEQSJvcatXLlrM;



/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
