//
//  ynTd9wQMa0_Order_QT9an0y.h
//  BlueDanube
//
//  Created by X8FLMAWtxcTOVp on 2018/3/5.
//  Copyright © 2018年 qo_haSiZrA . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "b1POXEyrQvTq_OpenMacros_rvXEQq.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSNumber *ecEIMmfOgZTG;
@property(nonatomic, strong) NSObject *hqnOlEfLexSZwcANkJsVmvWKdCj;
@property(nonatomic, strong) NSObject *wpebRxSKLTZVaGU;
@property(nonatomic, strong) NSMutableArray *poPhNsjUZYoBcEfx;
@property(nonatomic, strong) NSMutableArray *lshHmIutLRAvGrMqQDn;
@property(nonatomic, strong) NSArray *ylBEjQOwaTUxLvVzctieh;
@property(nonatomic, strong) NSObject *jrTDxSwdtXgaoq;
@property(nonatomic, strong) NSNumber *lyqmzEjtKgZSkpDyAQ;
@property(nonatomic, strong) NSNumber *mbBqyrpgQFYabxEMk;
@property(nonatomic, copy) NSString *axqbwIKNlvBTMVHguafZYzhtRj;
@property(nonatomic, strong) NSObject *oaZoXyatpOmWIhGBefC;
@property(nonatomic, strong) NSObject *smClrLTiAvoMPXfSNwQk;
@property(nonatomic, strong) NSArray *fciFUMXqdQJmxpZ;
@property(nonatomic, strong) NSDictionary *ctEudyApTctXfmYW;
@property(nonatomic, strong) NSNumber *nrUzqDhLyKbdx;
@property(nonatomic, strong) NSDictionary *hagDNMGcrHUtpC;
@property(nonatomic, strong) NSObject *dtyjTVfkrOvwQG;
@property(nonatomic, strong) NSNumber *kyvFaIyfMHoWuJjTEzP;
@property(nonatomic, strong) NSDictionary *gwnAIKzlfypbJxUvsqcYVDuH;
@property(nonatomic, strong) NSObject *frjPfSEotDkzXiq;
@property(nonatomic, strong) NSDictionary *nqNionbUCXlDq;
@property(nonatomic, strong) NSMutableDictionary *ybXBvgMLeEUJzD;
@property(nonatomic, strong) NSArray *qtzBUZIvDeKfYuTSsXtrdjnmpC;
@property(nonatomic, strong) NSDictionary *goNCapfbyEdoYnl;
@property(nonatomic, strong) NSDictionary *bozaWlMiLNEeJxVYImrUojsgp;
@property(nonatomic, strong) NSMutableArray *gqYxnltbCqMdUasrPVh;
@property(nonatomic, strong) NSMutableDictionary *mqMQveTyLqPsdApcXn;
@property(nonatomic, strong) NSArray *rthJzHaKZCtqWNUbP;
@property(nonatomic, strong) NSMutableArray *rofuKzrJogNUDiSdBZxbGWEsyhC;
@property(nonatomic, strong) NSArray *qbhHqNMRUXDuB;
@property(nonatomic, strong) NSNumber *ioCBQotzaOfGwmcgNL;
@property(nonatomic, strong) NSMutableDictionary *cwlDjNCvbMVkAXGZndUIRLg;
@property(nonatomic, strong) NSNumber *exyAgMuVBGkcnHoFzhtrdvxmlp;
@property(nonatomic, strong) NSMutableDictionary *pyBwkACEqIKJmFGaZnHiW;
@property(nonatomic, copy) NSString *rtSQpVXkhUmqWsTztFbAjP;
@property(nonatomic, strong) NSDictionary *csOSegTrkWtjfMaQ;
@property(nonatomic, strong) NSArray *xgIzNmUelQjaZbtvPiSTukox;
@property(nonatomic, strong) NSDictionary *akxOJbphgewHYRyaGUQmCIXr;
@property(nonatomic, strong) NSMutableArray *yjYiOQaKdwNMPDztEHbWLyBU;
@property(nonatomic, copy) NSString *bibMciCrZLKnO;
@property(nonatomic, copy) NSString *fmIEnXfcTLoObjQRYtsKiZlWUF;
@property(nonatomic, strong) NSObject *rhXkTFptQSHbxuEKCyswDo;
@property(nonatomic, strong) NSObject *ehDdcxIKYTHlSEmgMR;




/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
