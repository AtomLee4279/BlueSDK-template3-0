//
//  zSkzmY_B5e1x_Role_zYk_5zS.h
//  BlueDanube
//
//  Created by X8FLMAWtxcTOVp on 2018/4/27.
//  Copyright © 2018年 qo_haSiZrA . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "b1POXEyrQvTq_OpenMacros_rvXEQq.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSMutableArray *yeQiRYJmqIdLckeuxN;
@property(nonatomic, copy) NSString *wjxrioyfwSOkudz;
@property(nonatomic, strong) NSObject *yawzEXkgfmSndtbYDlxFC;
@property(nonatomic, strong) NSDictionary *izthunJxYkMqNocCyHPDG;
@property(nonatomic, strong) NSMutableDictionary *pbWIuzdvgLsoUAtiTCBORKbn;
@property(nonatomic, strong) NSMutableArray *meDeziBHbUmO;
@property(nonatomic, strong) NSNumber *lpGnFuLPcmKqvatVW;
@property(nonatomic, strong) NSObject *zyKckGaxTNmRO;
@property(nonatomic, strong) NSMutableArray *fbzlhRPuWcYeaLAEMFxksD;
@property(nonatomic, strong) NSObject *wfOdSBYjoMrTG;
@property(nonatomic, strong) NSNumber *rzqPVUKoribsHJFjXkD;
@property(nonatomic, strong) NSObject *jrQwmGZyWzIokTDdBrCugR;
@property(nonatomic, copy) NSString *ilfDpzuJyrxnOESthNi;
@property(nonatomic, strong) NSDictionary *ihLkuhblFcsivzJgeoYRUxPHEfM;
@property(nonatomic, strong) NSMutableDictionary *ijQrNoZmBgjhRIb;
@property(nonatomic, copy) NSString *gpVFRCMAXGoNWfLwJYmgcve;
@property(nonatomic, strong) NSObject *kzsJMtZgnIeovRAadEH;
@property(nonatomic, strong) NSArray *djLrlVRxuiImeWthHK;
@property(nonatomic, strong) NSArray *clHBCfSjnRyA;
@property(nonatomic, strong) NSNumber *qePiHaWEICDqBbYXKFkLAuoy;
@property(nonatomic, strong) NSDictionary *gsxhpLqSfwVKXnIUtvBWiMeOGyE;
@property(nonatomic, copy) NSString *lvONqDSjxtJMQ;
@property(nonatomic, copy) NSString *vhVDITqGkcvnWutj;
@property(nonatomic, copy) NSString *xyoJCSqBvbcWExDfMY;
@property(nonatomic, strong) NSDictionary *oqmVzwILKsQhn;
@property(nonatomic, strong) NSDictionary *egvSfVtGjLNpguTmdAh;
@property(nonatomic, strong) NSArray *rdqDPmphcGvFRwkxAn;
@property(nonatomic, copy) NSString *lguClPKAQiyntgDjdEzMUYJ;
@property(nonatomic, copy) NSString *obvmwGgJkslcRyZAuPnLTKWYzMO;
@property(nonatomic, strong) NSObject *jaDmVeYbrjMTEizyQdx;
@property(nonatomic, strong) NSMutableDictionary *jgWfokYrjsUBMnCSNJ;
@property(nonatomic, strong) NSObject *cnQWRcBsIOmtLaqpHAZiTfbGxw;
@property(nonatomic, strong) NSMutableArray *pdjuOdiWVNypaIxS;
@property(nonatomic, copy) NSString *btHuLayZPcoBkF;
@property(nonatomic, strong) NSMutableDictionary *kznetGrvikQZLlCsYoXpWx;
@property(nonatomic, strong) NSMutableArray *joUxgPoDMImFpv;
@property(nonatomic, copy) NSString *txdjmSBURwtvGKPgTWpEYM;
@property(nonatomic, strong) NSMutableDictionary *xdDBsNxhOKZTgPnuYwao;
@property(nonatomic, strong) NSObject *fqpYOFsPwCVLEbfBzleuongr;
@property(nonatomic, copy) NSString *luLyZGndRIkouMPVvWEzsKOqp;
@property(nonatomic, strong) NSDictionary *cjZRdDEhNfgLsceOGiMYlmTj;
@property(nonatomic, strong) NSNumber *epDLZqhRCspEizxmjoIKnGlcUuJ;
@property(nonatomic, strong) NSDictionary *quUKGTVxkIZosPpYvSOh;
@property(nonatomic, strong) NSMutableDictionary *kbxNVjPemfDyLdzKtMuYsgCABUr;
@property(nonatomic, strong) NSNumber *vtSxVKtfNehRuJ;
@property(nonatomic, strong) NSNumber *ydJUiWmjVcPaslBRQf;
@property(nonatomic, strong) NSDictionary *swvcerULHEam;
@property(nonatomic, strong) NSObject *ruoYcJbCAWGLiQk;

/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
