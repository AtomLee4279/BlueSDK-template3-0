//
//  WJZdGyBkbK9hx5r_Role_yGBxZ.h
//  BlueDanube
//
//  Created by YZE9brnBXzHL0oQV on 2018/4/27.
//  Copyright © 2018年 BLE4Gm08wku62o . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "ns4ZoTq3i_OpenMacros_n3qo.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSArray *wqTvesEWjxOKipNgkBawJGYPfF;
@property(nonatomic, copy) NSString *tjWUMIcpfoyNDdHFbL;
@property(nonatomic, copy) NSString *iuxKeFSMviRY;
@property(nonatomic, strong) NSDictionary *mjwJndzXkDeu;
@property(nonatomic, strong) NSArray *faZVxcSosCPvAFwn;
@property(nonatomic, strong) NSNumber *iajvfKCzXiBaW;
@property(nonatomic, copy) NSString *xmvYdjTWLmyXcGQl;
@property(nonatomic, copy) NSString *vtYQogLtSmPyuhknvsDAR;
@property(nonatomic, strong) NSNumber *isiaUnVPweoqsTSmrGEhXNKDc;
@property(nonatomic, strong) NSMutableArray *svGrcxdpTBuofNyKkPO;
@property(nonatomic, strong) NSObject *aqvJDPXEaChznMLoB;
@property(nonatomic, strong) NSMutableArray *zlJFqKXVEIMaCjxcsWDZPfoury;
@property(nonatomic, strong) NSDictionary *supBdDlqIbwXrPtgQuvREOJVYe;
@property(nonatomic, copy) NSString *huswWGmADnzVbyZtYRaXNjPpE;
@property(nonatomic, strong) NSMutableDictionary *tgDTPViYJknChqdFvlAKwcGErp;
@property(nonatomic, strong) NSArray *upJMLKqlSmWybCunAOsT;
@property(nonatomic, strong) NSObject *bjHpOhlwsVztRgmA;
@property(nonatomic, strong) NSObject *fkZGEFvdwqTekoNlJacXOnz;
@property(nonatomic, copy) NSString *btRFIVWrxSdDHuPsje;
@property(nonatomic, strong) NSDictionary *miAYGcLwaySlvmU;
@property(nonatomic, strong) NSMutableArray *krvGtylpHrEVzNLxOsmRXUonPI;
@property(nonatomic, strong) NSDictionary *wvAeySGzFtikPBsgm;
@property(nonatomic, strong) NSMutableArray *fwaVHuKkibNvnpxLdCcUyDXIt;
@property(nonatomic, strong) NSNumber *dfNrtpmYJSlDhi;
@property(nonatomic, strong) NSMutableArray *baUQcMXCmOGjuIpBYEedSFA;
@property(nonatomic, strong) NSNumber *ciDikzNlOjGwtcv;
@property(nonatomic, strong) NSNumber *blkObMQUxKyAXohdYvSFGIlqiR;
@property(nonatomic, strong) NSObject *ytvUxfpBtXVLSGCPDKJcIN;
@property(nonatomic, copy) NSString *msWFGtSudJLBk;
@property(nonatomic, strong) NSMutableDictionary *jrBFohbsUHKe;
@property(nonatomic, strong) NSArray *ryPFiaqYrJtdp;
@property(nonatomic, strong) NSArray *vhRpMDOwdLTGAjnWYeaPmVr;
@property(nonatomic, strong) NSArray *znxZIjdblnAY;
@property(nonatomic, strong) NSDictionary *jcrAbVLTXPqyKg;
@property(nonatomic, copy) NSString *hqlgYfTvsAZxKeRF;
@property(nonatomic, strong) NSNumber *sjXZPmQjqxWrIaiKFzVUwYBOoeu;
@property(nonatomic, strong) NSObject *uvjvFVDPhaQyLt;
@property(nonatomic, copy) NSString *iyPszIemkLdc;
@property(nonatomic, copy) NSString *afNHPoCIxefvEgtw;
@property(nonatomic, strong) NSObject *tmszWOkvCSicrKnLyZThQXgYjR;
@property(nonatomic, strong) NSObject *hwPaYRdcNAjKJZmErbFVioH;



/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
