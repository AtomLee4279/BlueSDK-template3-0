#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala LgFoDiQBwp35EyGjIeZbt
#define KKUser pMV0KwDbzuN
#define KKRole _vkzGglRxawXf
#define KKResult cl4ImYwdOxKQEAtJzR
#define KKOrder E4LaXeAdEQVqtfW
#define KKConfig LGHKpqUijLv
#define kgk_settleBillWithOrder oQCFJ4H17L0XYU
#define kgk_switchAccounts h5YnU3RsS7tdmNe4kE0Dj
#define kgk_postRoleInfoWithModel mfZzDLKr2sW_Mv3
#define kgk_initGameKitWithCompletionHandler jlIBR1arZX4FjpJTPKyG
#define kgk_openLog Pd2LK5UgsV40zT39Oh
#define kgk_demo_setPkver FHozSwnvflq
#define kgk_loginWithViewController yLUgECb7uBkcS

#endif
