#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKUser PgaV8w7nIXspdP
#define KKRole WmBRG70xYFUHpn6Q
#define Koala btDAif1x4HP5
#define KKResult a3fKZxk8NhWmogRVw
#define KKConfig aidrkEgboQ5lsnZjuIvMU
#define KKOrder MyL4Gz3rvSaA9D
#define kgk_settleBillWithOrder qEfPXNAimxlC_RSZD89
#define kgk_initGameKitWithCompletionHandler esS_voHFb4e9yB2ZgRC1
#define kgk_openLog oA9zqDV431nI
#define kgk_demo_setPkver EhiLfql6BrwaRF5D
#define kgk_loginWithViewController zrGL7d518F4UCSkqHVWP
#define kgk_switchAccounts aY8L7_PSTsaXK
#define kgk_postRoleInfoWithModel EZ1qSkEsNBClQT5

#endif
