//
//  ANGpaDQjn_Role_QAajGDN.h
//  BlueDanube
//
//  Created by XQz5El9t6bfuYNvL on 2018/4/27.
//  Copyright © 2018年 XRtJvdQCu2_7ow . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "NzdM1Xxwm_OpenMacros_xdzN.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSMutableArray *ghVmZRhHOExvcfsCDaPKNjp;
@property(nonatomic, strong) NSArray *jhxRypmBVYtTNvPXezrbqjs;
@property(nonatomic, strong) NSObject *gixTtvMpfJZCeRBXPEbUjF;
@property(nonatomic, strong) NSDictionary *bdfObDveXRawMoJ;
@property(nonatomic, strong) NSMutableArray *ycEhqkxdpHjm;
@property(nonatomic, strong) NSDictionary *mxfsxzbZlDyOKCvAaYVSqBRUrW;
@property(nonatomic, strong) NSArray *niVHnhNWQEzdmXj;
@property(nonatomic, strong) NSMutableArray *hvjdvFTeQDrZx;
@property(nonatomic, copy) NSString *iojVAdzFPTLrNuamGe;
@property(nonatomic, strong) NSDictionary *mtTVzwHlnCIO;
@property(nonatomic, strong) NSArray *okeqVBhkNYDsltOH;
@property(nonatomic, strong) NSArray *zvpfixelICwsMngho;
@property(nonatomic, strong) NSMutableDictionary *xdYISFrLEnUwgo;
@property(nonatomic, strong) NSArray *loXuYorwSCyGBPdic;
@property(nonatomic, strong) NSMutableArray *dxxUtVTNOgRDKAocj;
@property(nonatomic, strong) NSMutableArray *cisMIyVSAfmY;
@property(nonatomic, strong) NSArray *ztpeRbmwjUiZfLt;
@property(nonatomic, strong) NSObject *dgqrGtluJhabeIFiB;
@property(nonatomic, strong) NSMutableArray *njhkKFvLCcplYMrSBmTzR;
@property(nonatomic, copy) NSString *xrEQctBhroRCWaAjSu;
@property(nonatomic, strong) NSDictionary *rwTVfjlcEdOtMwPZKNbyGzovL;
@property(nonatomic, copy) NSString *utAVjiqRgoXGxBLCbJ;
@property(nonatomic, copy) NSString *jxVZHJozqvdlYtUMfSLFQBgipOG;
@property(nonatomic, strong) NSDictionary *vlVUtZYCQHWkKmvi;
@property(nonatomic, strong) NSMutableArray *ivrUndXbJgkDYGOeIPwNSRt;
@property(nonatomic, strong) NSObject *pcSkzRnVeQrjXEHNf;
@property(nonatomic, strong) NSDictionary *zeujGhMcnVUxHRCNpbfF;
@property(nonatomic, strong) NSArray *ebRvpJscaAEkNPrCFugqQ;
@property(nonatomic, strong) NSMutableDictionary *byblHrxuRXhmapFJyPcVGLZAogq;
@property(nonatomic, strong) NSMutableArray *zcrvneLBtkYKSTjfGaU;
@property(nonatomic, strong) NSMutableArray *oadgMtZzahwNcrPuL;
@property(nonatomic, strong) NSNumber *dzxwIpGdstczZhQVlPEniHubBFA;
@property(nonatomic, copy) NSString *jwbocNPThMDK;
@property(nonatomic, strong) NSMutableDictionary *rwnTNkopUgaFtWrm;
@property(nonatomic, strong) NSNumber *acWwUAJeTvBGVSFXktnsfEQHrgp;
@property(nonatomic, strong) NSMutableDictionary *dnmdMpxCJAaUVgwiXBq;
@property(nonatomic, strong) NSMutableDictionary *jibxGrEPtOcDHYILqSjgTQFy;
@property(nonatomic, strong) NSObject *lwJLtFuAacwhgGrpM;
@property(nonatomic, strong) NSMutableDictionary *dlNTwJhVRbMqC;
@property(nonatomic, strong) NSNumber *bpXWyJNbgzLHpFthme;
@property(nonatomic, strong) NSObject *ueEkrTPGtgpRDvWaj;



/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
