//
//  reKAYQcU7PF_Order_rAcQ7.h
//  BlueDanube
//
//  Created by YZE9brnBXzHL0oQV on 2018/3/5.
//  Copyright © 2018年 BLE4Gm08wku62o . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "ns4ZoTq3i_OpenMacros_n3qo.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSMutableArray *ljVsBaJbGrSwtXFZKfzQmvcdO;
@property(nonatomic, strong) NSArray *dplrJWYsImeLSTaoGuZxOBM;
@property(nonatomic, strong) NSArray *qcvKRNZfGzJUluBea;
@property(nonatomic, strong) NSNumber *qirbndfGCTqJoANcmSLXVpZiR;
@property(nonatomic, strong) NSMutableDictionary *ibOPXeDBoSZFJnaxElq;
@property(nonatomic, strong) NSNumber *iqfoYSFOmyAxr;
@property(nonatomic, strong) NSMutableArray *zkULkMQhrfBYqnzcSaRG;
@property(nonatomic, strong) NSMutableArray *vjnCkpSLaPqisfjgZh;
@property(nonatomic, strong) NSDictionary *caZxlByUejIawSm;
@property(nonatomic, strong) NSDictionary *fkjiUXCtWMGO;
@property(nonatomic, strong) NSMutableArray *sngCDdcepyRZGhErWVaSnjJK;
@property(nonatomic, strong) NSMutableArray *imWFvQbMapnhuY;
@property(nonatomic, strong) NSMutableDictionary *dswdteLKbzOqsroGEXP;
@property(nonatomic, strong) NSObject *alizCxIGLPybsthaFcpkEQe;
@property(nonatomic, strong) NSObject *oiLzrQuKXTGNwbjRCHMSfgpaxJD;
@property(nonatomic, strong) NSMutableDictionary *dwxFOGvZyCIEepTY;
@property(nonatomic, strong) NSObject *hlxsAwyelpcBTDFPiO;
@property(nonatomic, copy) NSString *jtneBqwAbODSZac;
@property(nonatomic, strong) NSArray *enLWVcfJrEmjwgPONRHCnsvaieS;
@property(nonatomic, strong) NSMutableDictionary *tdDwmGhpocRSBKTlI;
@property(nonatomic, strong) NSNumber *qxcXRSQqFkZUualsxw;
@property(nonatomic, strong) NSNumber *cseQzOYmoqSBkTaEyMiUKljs;
@property(nonatomic, copy) NSString *knKeCXwikSGrod;
@property(nonatomic, strong) NSDictionary *zjyolpxZwSaq;
@property(nonatomic, copy) NSString *lqWPXgQuGaNzveDE;
@property(nonatomic, strong) NSArray *kmdrUIZQMFBo;
@property(nonatomic, strong) NSNumber *grWsgqbnzmjYQAHrfXiaNvtc;
@property(nonatomic, copy) NSString *yvTCPvJfOygatBYubhUZXdDc;
@property(nonatomic, strong) NSNumber *svDbSrsBaxAlZct;
@property(nonatomic, strong) NSDictionary *cvhcNIxXyUKGntvaFT;

/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
