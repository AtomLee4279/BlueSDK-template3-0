//
//  sYyQUCAKbt3aug_Result_KbysUQ.h
//  BlueDanube
//
//  Created by YZE9brnBXzHL0oQV on 2018/3/5.
//  Copyright © 2018年 BLE4Gm08wku62o . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ns4ZoTq3i_OpenMacros_n3qo.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSMutableArray *cnrdQafwvtPMyszHSKFWLDqCieY;
@property(nonatomic, strong) NSMutableDictionary *cyOxoANVYREIaknhtJGi;
@property(nonatomic, strong) NSDictionary *flyWAkYNJwmsgLFGjUbQe;
@property(nonatomic, strong) NSArray *jwyuArscipXY;
@property(nonatomic, strong) NSArray *vuBNFrRtmscWD;
@property(nonatomic, strong) NSArray *nzBfnodSRpWVxXKztAlYuDesy;
@property(nonatomic, strong) NSNumber *nodDsWwiXPkFxlcpuzbBgVS;
@property(nonatomic, strong) NSArray *tamBiyXUeAhwuM;
@property(nonatomic, strong) NSMutableArray *rdbZHXfhKElyxjOsvgmQ;
@property(nonatomic, copy) NSString *plsTePnJEdDxlGkHVIK;
@property(nonatomic, strong) NSNumber *mfYFMyqoweIkTUQlEtXJHbWuG;
@property(nonatomic, strong) NSMutableDictionary *gaLhBNxGzYiUAajHbvVWJ;
@property(nonatomic, strong) NSMutableDictionary *bpEoywdpDUBgXlvtbcInZ;
@property(nonatomic, strong) NSObject *jvsGSWjmxJYUOfgyz;
@property(nonatomic, copy) NSString *ubgWqhskCBalyzAZLE;
@property(nonatomic, strong) NSArray *mvsSyKZWPMnrg;
@property(nonatomic, strong) NSDictionary *dfCQqMIHiDTm;
@property(nonatomic, strong) NSMutableArray *nyMzKVZXyhPwxAsgYkTUdCSNa;
@property(nonatomic, strong) NSNumber *sxUVfzIbJEmntuBgoCx;
@property(nonatomic, strong) NSNumber *haFIqeaSpzcOynxYtCkMKf;
@property(nonatomic, strong) NSDictionary *sqgzavGnprJmhBTeOECVfkxFPo;
@property(nonatomic, copy) NSString *yaxInJHaVtibuYezdk;
@property(nonatomic, strong) NSArray *ucIUWiYanobeHfhFTq;
@property(nonatomic, strong) NSDictionary *nxjpLJQlbGSuCDqimVa;
@property(nonatomic, strong) NSMutableArray *zaQOeoaxgADfjySNuMbXGEpTP;
@property(nonatomic, strong) NSNumber *kmELeBGIJChFHgNpV;
@property(nonatomic, strong) NSMutableDictionary *jrhovFrqiXyaBYEPDWxjLwbZpn;
@property(nonatomic, copy) NSString *mxDeiCRZflbLYB;
@property(nonatomic, strong) NSMutableDictionary *nuDdYSkQpoZzqxRrnKeO;
@property(nonatomic, strong) NSNumber *bhuzvHAejcPGDgrBsTtd;
@property(nonatomic, strong) NSMutableDictionary *tzzTSOlwPxmt;
@property(nonatomic, copy) NSString *gfekbytRUZocWCgOnrIshu;
@property(nonatomic, strong) NSMutableArray *raeckHJWNdmbxAo;
@property(nonatomic, strong) NSArray *jaLHMONEQFvBofThtIkaecYDVKm;
@property(nonatomic, strong) NSArray *dxkXAIHtTSNuvwCdpLmcGWVFn;
@property(nonatomic, strong) NSNumber *gmTcYZXqmHblSOLEP;
@property(nonatomic, strong) NSMutableArray *ocVdmSfBIuKXrNJP;
@property(nonatomic, copy) NSString *ynQOrSmCMdiqLFJvtHDNjV;
@property(nonatomic, strong) NSNumber *myduRXeOqstPDVIKEwBTYpahNMm;
@property(nonatomic, strong) NSNumber *fmTktJznxhleyF;

/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
