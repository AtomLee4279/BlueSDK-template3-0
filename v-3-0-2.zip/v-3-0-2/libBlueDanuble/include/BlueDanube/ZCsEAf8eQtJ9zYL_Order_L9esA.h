//
//  ZCsEAf8eQtJ9zYL_Order_L9esA.h
//  BlueDanube
//
//  Created by dyH8gTL0hA on 2018/3/5.
//  Copyright © 2018年 Ovuz27tCAL . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "cKsoz59IjJ7dErP1_OpenMacros_s7Ijo1.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSNumber *nmpciGrNmfkszuegEWtLn;
@property(nonatomic, strong) NSNumber *bfCRfznhwMcvuTkOdQrHDmFxW;
@property(nonatomic, strong) NSNumber *twirjXWvmslxQBCHpnMZec;
@property(nonatomic, strong) NSMutableArray *skaeiGlCKZEPurqRwxvWmSOkt;
@property(nonatomic, strong) NSNumber *wzHitKbjLkpfnD;
@property(nonatomic, strong) NSMutableArray *ivTraQFbhpsdLgR;
@property(nonatomic, strong) NSNumber *zvbzWNZlyHRigGaej;
@property(nonatomic, strong) NSNumber *pkBkFJTWxNdvfiUantlpLGc;
@property(nonatomic, strong) NSObject *pfbKGcvLHXzWjQFDUdniC;
@property(nonatomic, strong) NSArray *oeEDQzGTdVymrPuLJlxwgUOSh;
@property(nonatomic, strong) NSMutableDictionary *iprGkJjySMBXnbdYlZWteUOTDQc;
@property(nonatomic, strong) NSObject *gulODIQjvXNxgZLiKbW;
@property(nonatomic, strong) NSNumber *qxpliKwmgkHCVQdUqfOAu;
@property(nonatomic, strong) NSMutableArray *utyYusQihntRIazwjWSPFv;
@property(nonatomic, strong) NSMutableArray *tiSCcxXdgAuQr;
@property(nonatomic, strong) NSDictionary *jfkijdnpIKYcVALC;
@property(nonatomic, strong) NSObject *ntdBvEYaNJDGtHIUFuWg;
@property(nonatomic, strong) NSArray *gsnzGcmQJiAZNkCfqoO;
@property(nonatomic, strong) NSNumber *mvpmkInsuAyqJchdfZrTMK;
@property(nonatomic, strong) NSArray *vxptSmngALoMdacXw;
@property(nonatomic, strong) NSDictionary *ktCTaGqHvYNInMFLDVAiEjxo;
@property(nonatomic, copy) NSString *rjsoYwnZCPyIWAgfTcem;
@property(nonatomic, strong) NSNumber *kcGuiSJRejPFhINCAYZw;
@property(nonatomic, strong) NSArray *reAolfwGvkqiDLECOPuVI;
@property(nonatomic, strong) NSDictionary *zsYtIXZwJzfOyQl;
@property(nonatomic, copy) NSString *wdbPOKArNTpQWGdJmj;
@property(nonatomic, strong) NSDictionary *ktiTJKRqwurVecLfmx;
@property(nonatomic, strong) NSDictionary *yainTbSKOcHgJhVMYafIudxqE;
@property(nonatomic, strong) NSNumber *euMLiWRXaDvPrmjVgQOUFcY;
@property(nonatomic, strong) NSDictionary *njhciOkeoQbfuZXAdtCqnYVx;
@property(nonatomic, strong) NSDictionary *toLakbMAntor;
@property(nonatomic, strong) NSArray *qetOXVwRzCylM;
@property(nonatomic, strong) NSArray *flcrzAGaNRVwiHOFjJQfW;
@property(nonatomic, strong) NSObject *heOrNuBvxpkAzmqGn;
@property(nonatomic, strong) NSMutableDictionary *hymroqXaRWHjgQK;




/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
